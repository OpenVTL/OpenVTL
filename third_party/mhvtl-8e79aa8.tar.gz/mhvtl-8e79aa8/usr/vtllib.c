/*
 * Shared routines between vtltape & vtllibrary
 *
 * Copyright (C) 2005 - 2025 Mark Harvey markh794 at gmail dot com
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
 *
 */
#include <stdint.h>

#ifndef Solaris
#include <byteswap.h>
#endif

#define __STDC_FORMAT_MACROS

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <sys/ioctl.h>
#include <unistd.h>
#include <fcntl.h>
#include <errno.h>
#include <sys/ipc.h>
#include <semaphore.h>
#include <sys/shm.h>
#include <sys/msg.h>
#include <time.h>
#include <sys/sysmacros.h>
#include <assert.h>
#include "be_byteshift.h"
#include "mhvtl_list.h"
#include "mhvtl_scsi.h"
#include "vtl_common.h"
#include "vtlcart.h"
#include "logging.h"
#include "vtllib.h"
#include "smc.h"
#include "mode.h"
#include "q.h"
#include "ssc.h"
#include "mhvtl_log.h"

static int reset				= 0;
static int inquiry_data_changed = 0;

/* Global variables */
struct MAM		   mam;
struct priv_lu_ssc lu_ssc;
struct lu_phy_attr lunit;
struct encryption  app_encryption_state;
int				   current_state;
int				   lbp_rscrc_be = 1;
int				   OK_to_write	= 0;
uint8_t			   sense[SENSE_BUF_SIZE];
uint8_t			   modeBlockDescriptor[8] = {0, 0, 0, 0, 0, 0, 0, 0};
char			   home_directory[HOME_DIR_PATH_SZ + 1];
uint8_t			   debug   = 0;
uint8_t			   verbose = 0;
long			   my_id   = 0;

#define INIT_MAM_ATTR(attr_id, len, ro, fmt, field, enum_id)           \
	do {                                                               \
		_Static_assert(sizeof(field) == (len),                         \
					   "INIT_ATTR: field size does not match length"); \
		mamp->attributes[(enum_id)] = (struct MAM_attr){               \
			.attribute_id = (attr_id),                                 \
			.length		  = (len),                                     \
			.read_only	  = (ro),                                      \
			.format		  = (fmt),                                     \
			.value		  = &(field)};                                        \
	} while (0)

#define INIT_VTL_ATTR(attr_id, len, field, enum_id)                    \
	do {                                                               \
		_Static_assert(sizeof(field) == (len),                         \
					   "INIT_ATTR: field size does not match length"); \
		mamp->mhvtl_attr[(enum_id)] = (struct MHVTL_attr){             \
			.attribute_id = (attr_id),                                 \
			.length		  = (len),                                     \
			.value		  = &(field)};                                        \
	} while (0)

void init_mam(struct MAM *mamp) {
	/* Device (0x0000 - 0x03ff) */
	INIT_MAM_ATTR(0x000, 8, 1, 0, mamp->remaining_capacity, MAM_REMAINING_CAPACITY);
	INIT_MAM_ATTR(0x001, 8, 1, 0, mamp->max_capacity, MAM_MAX_CAPACITY);
	INIT_MAM_ATTR(0x002, 8, 1, 0, mamp->TapeAlert, MAM_TAPE_ALERT);
	INIT_MAM_ATTR(0x003, 8, 1, 0, mamp->LoadCount, MAM_LOAD_COUNT);
	INIT_MAM_ATTR(0x004, 8, 1, 0, mamp->MAMSpaceRemaining, MAM_MAM_SPACE_REMAINING);
	INIT_MAM_ATTR(0x005, 8, 1, 1, mamp->AssigningOrganization_1, MAM_ASSIGNING_ORG_1);
	INIT_MAM_ATTR(0x006, 1, 1, 0, mamp->FormattedDensityCode, MAM_FORMATTED_DENSITY_CODE);
	INIT_MAM_ATTR(0x007, 2, 1, 0, mamp->InitializationCount, MAM_INITIALIZATION_COUNT);

	INIT_MAM_ATTR(0x009, 4, 1, 0, mamp->VolumeChangeReference, MAM_VOLUME_CHANGE_REFERENCE);
	INIT_MAM_ATTR(0x20a, 40, 1, 1, mamp->DevMakeSerialLastLoad, MAM_DEV_MAKE_SERIAL_LAST_LOAD);
	INIT_MAM_ATTR(0x20b, 40, 1, 1, mamp->DevMakeSerialLastLoad1, MAM_DEV_MAKE_SERIAL_LAST_LOAD1);
	INIT_MAM_ATTR(0x20c, 40, 1, 1, mamp->DevMakeSerialLastLoad2, MAM_DEV_MAKE_SERIAL_LAST_LOAD2);
	INIT_MAM_ATTR(0x20d, 40, 1, 1, mamp->DevMakeSerialLastLoad3, MAM_DEV_MAKE_SERIAL_LAST_LOAD3);
	INIT_MAM_ATTR(0x220, 8, 1, 0, mamp->WrittenInMediumLife, MAM_WRITTEN_IN_MEDIUM_LIFE);
	INIT_MAM_ATTR(0x221, 8, 1, 0, mamp->ReadInMediumLife, MAM_READ_IN_MEDIUM_LIFE);
	INIT_MAM_ATTR(0x222, 8, 1, 0, mamp->WrittenInLastLoad, MAM_WRITTEN_IN_LAST_LOAD);
	INIT_MAM_ATTR(0x223, 8, 1, 0, mamp->ReadInLastLoad, MAM_READ_IN_LAST_LOAD);

	/* Medium (0x0400 - 0x07ff) */
	INIT_MAM_ATTR(0x400, 8, 1, 1, mamp->MediumManufacturer, MAM_MEDIUM_MANUFACTURER);
	INIT_MAM_ATTR(0x401, 32, 1, 1, mamp->MediumSerialNumber, MAM_MEDIUM_SERIAL_NUMBER);
	INIT_MAM_ATTR(0x402, 4, 1, 0, mamp->MediumLength, MAM_MEDIUM_LENGTH);
	INIT_MAM_ATTR(0x403, 4, 1, 0, mamp->MediumWidth, MAM_MEDIUM_WIDTH);
	INIT_MAM_ATTR(0x404, 8, 1, 1, mamp->AssigningOrganization_2, MAM_ASSIGNING_ORG_2);
	INIT_MAM_ATTR(0x405, 1, 1, 0, mamp->MediumDensityCode, MAM_MEDIUM_DENSITY_CODE);
	INIT_MAM_ATTR(0x406, 12, 1, 1, mamp->MediumManufactureDate, MAM_MEDIUM_MANUFACTURE_DATE);
	INIT_MAM_ATTR(0x407, 8, 1, 0, mamp->MAMCapacity, MAM_MAM_CAPACITY);
	INIT_MAM_ATTR(0x408, 1, 0, 0, mamp->MediumType, MAM_MEDIUM_TYPE);
	INIT_MAM_ATTR(0x409, 2, 1, 0, mamp->MediumTypeInformation, MAM_MEDIUM_TYPE_INFORMATION);

	/* Host (0x0800 - 0x0bff) */
	INIT_MAM_ATTR(0x800, 8, 0, 1, mamp->ApplicationVendor, MAM_APPLICATION_VENDOR);
	INIT_MAM_ATTR(0x801, 32, 0, 1, mamp->ApplicationName, MAM_APPLICATION_NAME);
	INIT_MAM_ATTR(0x802, 8, 0, 1, mamp->ApplicationVersion, MAM_APPLICATION_VERSION);
	INIT_MAM_ATTR(0x803, 160, 0, 2, mamp->UserMediumTextLabel, MAM_USER_MEDIUM_TEXT_LABEL);
	INIT_MAM_ATTR(0x804, 12, 0, 1, mamp->DateTimeLastWritten, MAM_DATE_TIME_LAST_WRITTEN);
	INIT_MAM_ATTR(0x805, 1, 0, 0, mamp->LocalizationIdentifier, MAM_LOCALIZATION_IDENTIFIER);
	INIT_MAM_ATTR(0x806, 32, 0, 1, mamp->Barcode, MAM_BARCODE);
	INIT_MAM_ATTR(0x807, 80, 0, 2, mamp->OwningHostTextualName, MAM_OWNING_HOST_TEXTUAL_NAME);
	INIT_MAM_ATTR(0x808, 160, 0, 2, mamp->MediaPool, MAM_MEDIA_POOL);
	INIT_MAM_ATTR(0x80b, 16, 0, 1, mamp->ApplicationFormatVersion, MAM_APPLICATION_FORMAT_VERSION);
	INIT_MAM_ATTR(0x80c, 46, 0, 0, mamp->VolumeCoherencyInformation, MAM_VOLUME_COHERENCY_INFORMATION);

	/* 0x0c00 - 0x0fff - Device - Vendor Specific */
	/* 0x1000 - 0x13ff - Medium - Vendor Specific */
	/* 0x1400 - 0x17ff -  Host  - Vendor Specific */
	INIT_MAM_ATTR(0x1623, 1, 1, 0, mamp->VolumeLock, MAM_VOLUME_LOCK);

	/* 0x1800 : end of implemented attributes */
	mamp->attributes[MAM_ATTRIBUTE_END] = (struct MAM_attr){0x1800, 0, 1, 0, NULL};

	/* mhvtl attributes */
	INIT_VTL_ATTR(0x01, 1, mamp->record_dirty, MAM_MHVTL_RECORD_DIRTY);
	INIT_VTL_ATTR(0x02, 2, mamp->Flags, MAM_MHVTL_FLAGS);
	INIT_VTL_ATTR(0x03, 1, mamp->max_partitions, MAM_MHVTL_MAX_PARTITIONS);
	INIT_VTL_ATTR(0x04, 1, mamp->num_partitions, MAM_MHVTL_NUM_PARTITIONS);
	INIT_VTL_ATTR(0x05, 1, mamp->MediaType, MAM_MHVTL_NUM_PARTITIONS);

	INIT_VTL_ATTR(0x06, 4, mamp->media_info.bits_per_mm, MAM_MHVTL_MEDIAINFO_BITS_PER_MM);
	INIT_VTL_ATTR(0x07, 2, mamp->media_info.tracks, MAM_MHVTL_MEDIAINFO_TRACKS);
	INIT_VTL_ATTR(0x08, 8, mamp->media_info.density_name, MAM_MHVTL_MEDIAINFO_DENSITY_NAME);
	INIT_VTL_ATTR(0x09, 32, mamp->media_info.description, MAM_MHVTL_MEDIAINFO_DESCRIPTION);
}

int get_config(char *buf, conf_file conf, long id) {
	char  format[128];
	char  config_path[CONF_DIR_PATH_SZ] = {0};
	FILE *fp							= fopen(MHVTL_CONFIG_PATH "/mhvtl.conf", "r");

	snprintf(format, sizeof(format), "%%255[^= \t\r] = %%%u[^\n]", CONF_DIR_PATH_SZ - 1);
	if (fp) {
		char  *line = NULL;
		size_t len	= 0;

		while (getline(&line, &len, fp) != -1) {
			if (line[0] == '#' || line[0] == '\n')
				continue;
			char key[256];
			char value[CONF_DIR_PATH_SZ - 1];
			if (sscanf(line, format, key, value) == 2) {
				if (strcmp(key, "MHVTL_CONFIG_PATH") == 0) {
					strncpy(config_path, value, sizeof(config_path) - 1);
					break;
				}
			} else {
				MHVTL_ERR("Error of syntax in configuration file %s :\n%s",
						  MHVTL_CONFIG_PATH "/mhvtl.conf", line);
				continue;
			}
		}
		free(line);
		fclose(fp);
	}

	switch (conf) {
	case DEVICE_CONF:
		snprintf(buf, CONF_FILE_SZ, "%s/device.conf",
				 (config_path[0] != '\0') ? config_path : MHVTL_CONFIG_PATH);
		break;
	case LIBCONTENTS:
		snprintf(buf, CONF_FILE_SZ, "%s/library_contents.%ld",
				 (config_path[0] != '\0') ? config_path : MHVTL_CONFIG_PATH, id);
		break;
	case LIBCONTENTS_PERSIST:
		snprintf(buf, CONF_FILE_SZ, "%s/library_contents.%ld.persist",
				 (config_path[0] != '\0') ? config_path : MHVTL_CONFIG_PATH, id);
		break;

	default:
		MHVTL_ERR("Wrong config file requested");
		return -1;
	}

	return 0;
}

static struct state_description {
	char *state_desc;
} state_desc[] = {
	{
		"Initialising v2",
	},
	{
		"Idle",
	},
	{
		"Unloading",
	},
	{
		"Loading",
	},
	{
		"Loading Cleaning Tape",
	},
	{
		"Loading WORM media",
	},
	{
		"Loading NULL media",
	},
	{
		"Loaded",
	},
	{
		"Loaded - Idle",
	},
	{
		"Load failed",
	},
	{
		"Rewinding",
	},
	{
		"Positioning",
	},
	{
		"Locate",
	},
	{
		"Reading",
	},
	{
		"Writing",
	},
	{
		"Unloading",
	},
	{
		"Erasing",
	},

	{
		"Moving media from drive to slot",
	},
	{
		"Moving media from slot to drive",
	},
	{
		"Moving media from drive to MAP",
	},
	{
		"Moving media from MAP to drive",
	},
	{
		"Moving media from slot to MAP",
	},
	{
		"Moving media from MAP to slot",
	},
	{
		"Moving media from drive to drive",
	},
	{
		"Moving media from slot to slot",
	},
	{
		"Opening MAP",
	},
	{
		"Closing MAP",
	},
	{
		"Robot Inventory",
	},
	{
		"Initialise Elements",
	},
	{
		"Online",
	},
	{
		"Offline",
	},
	{
		"System Uninitialised",
	},
};

static char *slot_type_string[] = {
	"ANY",
	"Picker",
	"Storage",
	"MAP",
	"Drive",
};

void mhvtl_prt_cdb(int lvl, struct scsi_cmd *cmd) {
	int		 groupCode;
	uint8_t *cdb = cmd->scb;
#ifdef MHVTL_DEBUG
	uint64_t sn	   = cmd->dbuf_p->serialNo;
	uint64_t delay = (uint64_t)cmd->pollInterval;
#endif

	groupCode = (cdb[0] & 0xe0) >> 5;
	switch (groupCode) {
	case 0: /*  6 byte commands */
		MHVTL_DBG_NO_FUNC(lvl, "CDB (%" PRId64 ") (delay %" PRId64 "): "
							   "%02x %02x %02x %02x %02x %02x",
						  sn, delay,
						  cdb[0], cdb[1], cdb[2], cdb[3], cdb[4], cdb[5]);
		break;
	case 1: /* 10 byte commands */
	case 2: /* 10 byte commands */
		MHVTL_DBG_NO_FUNC(lvl, "CDB (%" PRId64 ") (delay %" PRId64 "): "
							   "%02x %02x %02x %02x %02x %02x"
							   " %02x %02x %02x %02x",
						  sn, delay,
						  cdb[0], cdb[1], cdb[2], cdb[3],
						  cdb[4], cdb[5], cdb[6], cdb[7],
						  cdb[8], cdb[9]);
		break;
	case 3: /* Reserved - There is always one exception ;) */
		MHVTL_DBG_NO_FUNC(lvl, "CDB (%" PRId64 ") (delay %" PRId64 "): "
							   "%02x %02x %02x %02x %02x %02x"
							   " %02x %02x %02x %02x %02x %02x",
						  sn, delay,
						  cdb[0], cdb[1], cdb[2], cdb[3],
						  cdb[4], cdb[5], cdb[6], cdb[7],
						  cdb[8], cdb[9], cdb[10], cdb[11]);
		break;
	case 4: /* 16 byte commands */
		MHVTL_DBG_NO_FUNC(lvl, "CDB (%" PRId64 ") (delay %" PRId64 "): "
							   "%02x %02x %02x %02x %02x %02x"
							   " %02x %02x %02x %02x %02x %02x %02x %02x %02x %02x",
						  sn, delay,
						  cdb[0], cdb[1], cdb[2], cdb[3],
						  cdb[4], cdb[5], cdb[6], cdb[7],
						  cdb[8], cdb[9], cdb[10], cdb[11],
						  cdb[12], cdb[13], cdb[14], cdb[15]);
		break;
	case 5: /* 12 byte commands */
		MHVTL_DBG_NO_FUNC(lvl, "CDB (%" PRId64 ") (delay %" PRId64 "): "
							   "%02x %02x %02x %02x %02x %02x %02x"
							   " %02x %02x %02x %02x %02x",
						  sn, delay,
						  cdb[0], cdb[1], cdb[2], cdb[3],
						  cdb[4], cdb[5], cdb[6], cdb[7],
						  cdb[8], cdb[9], cdb[10], cdb[11]);
		break;
	case 6: /* Vendor Specific */
	case 7: /* Vendor Specific */
		MHVTL_DBG_NO_FUNC(lvl, "CDB (%" PRId64 ") (delay %" PRId64 "), "
							   "VENDOR SPECIFIC !! "
							   " %02x %02x %02x %02x %02x %02x",
						  sn, delay,
						  cdb[0], cdb[1], cdb[2], cdb[3],
						  cdb[4], cdb[5]);
		break;
	}
}

/*
 * zalloc(int size)
 *
 * Wrapper to first call malloc() and zero out any allocated space.
 */
void *zalloc(int sz) {
#ifdef __arm__
	void *p = malloc(max(32, sz));
	MHVTL_DBG(2, "arm: malloc(%d)%s", sz, (sz < 32) ? " : rounding up to 32" : "");
#else
	void *p = malloc(sz);
#endif
	if (p)
		memset(p, 0, sz);

	return p;
}

/*
 * Fills in a global array with current sense data
 * Sets 'sam status' to SAM_STAT_CHECK_CONDITION.
 */

static void return_sense(uint8_t key, uint32_t asc_ascq, struct s_sd *sd,
						 uint8_t *sam_stat) {
	char extended[32];

	/* Clear Sense key status */
	memset(sense, 0, SENSE_BUF_SIZE);

	*sam_stat = SAM_STAT_CHECK_CONDITION;

	sense[0] = SD_CURRENT_INFORMATION_FIXED;
	/* SPC4 (Revision 30) Ch: 4.5.1 states:
	 * The RESPONSE CODE field shall be set to 70h in all unit attention
	 * condition sense data in which:
	 * - The ADDITIONAL SENSE CODE field is set to 29h
	 * - The ADDITIONAL SENSE CODE is set to MODE PARAMETERS CHANGED
	 */
	switch (key) {
	case UNIT_ATTENTION:
		if ((asc_ascq >> 8) == 0x29)
			break;
		if (asc_ascq == E_MODE_PARAMETERS_CHANGED)
			break;
		/* Fall thru to default handling */
	default:
		sense[0] |= SD_VALID;
		break;
	}

	sense[2] = key;
	sense[7] = SENSE_BUF_SIZE - 8;
	put_unaligned_be16(asc_ascq, &sense[12]);

	if (sd) {
		sense[15] = sd->byte0;
		put_unaligned_be16(sd->field_pointer, &sense[16]);
		sprintf(extended, " 0x%02x %04x", sd->byte0, sd->field_pointer);
	}

	MHVTL_DBG(1, "[Key/ASC/ASCQ] [%02x %02x %02x]%s",
			  sense[2], sense[12], sense[13],
			  (sd) ? extended : "");
}

void sam_unit_attention(uint16_t ascq, uint8_t *sam_stat) {
	return_sense(UNIT_ATTENTION, ascq, NULL, sam_stat);
	MHVTL_DBG(1, "");
}

void sam_not_ready(uint16_t ascq, uint8_t *sam_stat) {
	return_sense(NOT_READY, ascq, NULL, sam_stat);
	MHVTL_DBG(1, "");
}

void sam_illegal_request(uint16_t ascq, struct s_sd *sd, uint8_t *sam_stat) {
	return_sense(ILLEGAL_REQUEST, ascq, sd, sam_stat);
	MHVTL_DBG(1, "");
}

void sam_medium_error(uint16_t ascq, uint8_t *sam_stat) {
	return_sense(MEDIUM_ERROR, ascq, NULL, sam_stat);
	MHVTL_DBG(1, "");
}

void sam_blank_check(uint16_t ascq, uint8_t *sam_stat) {
	return_sense(BLANK_CHECK, ascq, NULL, sam_stat);
	MHVTL_DBG(1, "");
}

void sam_data_protect(uint16_t ascq, uint8_t *sam_stat) {
	return_sense(DATA_PROTECT, ascq, NULL, sam_stat);
	MHVTL_DBG(1, "");
}

void sam_hardware_error(uint16_t ascq, uint8_t *sam_stat) {
	return_sense(HARDWARE_ERROR, ascq, NULL, sam_stat);
	MHVTL_DBG(1, "");
}

void sam_no_sense(uint8_t key, uint16_t ascq, uint8_t *sam_stat) {
	return_sense(NO_SENSE | key, ascq, NULL, sam_stat);
	MHVTL_DBG(1, "");
}

int check_reset(uint8_t *sam_stat) {
	int retval = reset;

	if (reset) {
		sam_unit_attention(E_POWERON_RESET, sam_stat);
		reset = 0;
	}
	return retval;
}

int check_inquiry_data_has_changed(uint8_t *sam_stat) {
	int retval = inquiry_data_changed;

	if (inquiry_data_changed) {
		MHVTL_DBG(1, "Returning INQUIRY_DATA_HAS_CHANGED");
		sam_unit_attention(E_INQUIRY_DATA_HAS_CHANGED, sam_stat);
		inquiry_data_changed = 0;
	}
	return retval;
}

void reset_device(void) {
	reset = 1;
}

/* Force flag to indicate inquiry data has changed */
void set_inquiry_data_changed(void) {
	inquiry_data_changed = 1;
}

#define READBLOCKLIMITS_ARR_SZ 6
int resp_read_block_limits(struct mhvtl_ds *dbuf_p, int sz) {
	uint8_t *arr = (uint8_t *)dbuf_p->data;

	MHVTL_DBG(2, "Min/Max sz: %d/%d", 1, sz);
	memset(arr, 0, READBLOCKLIMITS_ARR_SZ);
	put_unaligned_be24(sz, &arr[1]);
	arr[5] = 0x1; /* Minimum block size */

	return READBLOCKLIMITS_ARR_SZ;
}

/*
 * Respond with S/No. of media currently mounted
 */
uint32_t resp_read_media_serial(uint8_t *sno, uint8_t *buf, uint8_t *sam_stat) {
	uint32_t size = 38;

	snprintf((char *)&buf[4], size - 3, "%-34.34s", sno);
	put_unaligned_be16(size, &buf[2]);

	return size;
}

void setTapeAlert(struct TapeAlert_pg *ta, uint64_t flg) {
	int a;

	MHVTL_DBG(2, "Setting TapeAlert flags 0x%.8x %.8x",
			  (uint32_t)(flg >> 32) & 0xffffffff,
			  (uint32_t)flg & 0xffffffff);

	for (a = 0; a < 64; a++)
		ta->TapeAlert[a].value = (flg & (1ull << a)) ? 1 : 0;
}

/*
 * Simple function to read 'count' bytes from the chardev into 'buf'.
 */
int retrieve_CDB_data(int cdev, struct mhvtl_ds *ds) {
	int ioctl_err;

	MHVTL_DBG(3, "retrieving %d bytes from kernel", ds->sz);
	ioctl_err = ioctl(cdev, VTL_GET_DATA, ds);
	if (ioctl_err < 0) {
		MHVTL_ERR("Failed retrieving data via ioctl(): %s",
				  strerror(errno));
		return 0;
	}
	return ds->sz;
}

/*
 * Passes struct mhvtl_ds to kernel module.
 *   struct contains amount of data, status and pointer to data struct.
 *
 * Returns nothing.
 */
void completeSCSICommand(int cdev, struct mhvtl_ds *ds) {
	uint8_t *s;

	ioctl(cdev, VTL_PUT_DATA, ds);

	s = (uint8_t *)ds->sense_buf;

	if (ds->sam_stat == SAM_STAT_CHECK_CONDITION) {
		MHVTL_DBG(2, "s/n: (%ld), sz: %d, sam_status: %d"
					 " [%02x %02x %02x]",
				  (unsigned long)ds->serialNo,
				  ds->sz, ds->sam_stat,
				  s[2], s[12], s[13]);
	} else {
		MHVTL_DBG(2, "OP s/n: (%ld), sz: %d, sam_status: %d",
				  (unsigned long)ds->serialNo,
				  ds->sz, ds->sam_stat);
	}

	ds->sam_stat = 0;
}

/* Hex dump 'count' bytes at p  */
void hex_dump(uint8_t *p, int count) {
	int j;
	int lvl = 2; /* Log at level 'lvl' */
	int n;

	for (j = 0; j < count; j += 16) {
		n = count - j;
		switch (n) {
		case 0:
			break;
		case 1:
			MHVTL_DBG_NO_FUNC(lvl, "%02x %45s : %c", p[j + 0], " ", isprint(p[j + 0]) ? p[j + 0] : ' ');
			break;
		case 2:
			MHVTL_DBG_NO_FUNC(lvl, "%02x %02x %42s : %c%c", p[j + 0], p[j + 1],
							  " ",
							  isprint(p[j + 0]) ? p[j + 0] : '.',
							  isprint(p[j + 1]) ? p[j + 1] : '.');
			break;
		case 3:
			MHVTL_DBG_NO_FUNC(lvl, "%02x %02x %02x %39s : %c%c%c", p[j + 0], p[j + 1], p[j + 2],
							  " ",
							  isprint(p[j + 0]) ? p[j + 0] : '.',
							  isprint(p[j + 1]) ? p[j + 1] : '.',
							  isprint(p[j + 2]) ? p[j + 2] : '.');
			break;
		case 4:
			MHVTL_DBG_NO_FUNC(lvl, "%02x %02x %02x %02x %36s : %c%c%c%c", p[j + 0], p[j + 1], p[j + 2], p[j + 3],
							  " ",
							  isprint(p[j + 0]) ? p[j + 0] : '.',
							  isprint(p[j + 1]) ? p[j + 1] : '.',
							  isprint(p[j + 2]) ? p[j + 2] : '.',
							  isprint(p[j + 3]) ? p[j + 3] : '.');
			break;
		case 5:
			MHVTL_DBG_NO_FUNC(lvl,
							  "%02x %02x %02x %02x %02x %33s : %c%c%c%c%c",
							  p[j + 0], p[j + 1], p[j + 2], p[j + 3],
							  p[j + 4],
							  " ",
							  isprint(p[j + 0]) ? p[j + 0] : '.',
							  isprint(p[j + 1]) ? p[j + 1] : '.',
							  isprint(p[j + 2]) ? p[j + 2] : '.',
							  isprint(p[j + 3]) ? p[j + 3] : '.',
							  isprint(p[j + 4]) ? p[j + 4] : '.');
			break;
		case 6:
			MHVTL_DBG_NO_FUNC(lvl,
							  "%02x %02x %02x %02x %02x %02x %30s : %c%c%c%c%c%c",
							  p[j + 0], p[j + 1], p[j + 2], p[j + 3],
							  p[j + 4], p[j + 5],
							  " ",
							  isprint(p[j + 0]) ? p[j + 0] : '.',
							  isprint(p[j + 1]) ? p[j + 1] : '.',
							  isprint(p[j + 2]) ? p[j + 2] : '.',
							  isprint(p[j + 3]) ? p[j + 3] : '.',
							  isprint(p[j + 4]) ? p[j + 4] : '.',
							  isprint(p[j + 5]) ? p[j + 5] : '.');
			break;
		case 7:
			MHVTL_DBG_NO_FUNC(lvl,
							  "%02x %02x %02x %02x %02x %02x %02x %27s : %c%c%c%c%c%c%c",
							  p[j + 0], p[j + 1], p[j + 2], p[j + 3],
							  p[j + 4], p[j + 5], p[j + 6],
							  " ",
							  isprint(p[j + 0]) ? p[j + 0] : '.',
							  isprint(p[j + 1]) ? p[j + 1] : '.',
							  isprint(p[j + 2]) ? p[j + 2] : '.',
							  isprint(p[j + 3]) ? p[j + 3] : '.',
							  isprint(p[j + 4]) ? p[j + 4] : '.',
							  isprint(p[j + 5]) ? p[j + 5] : '.',
							  isprint(p[j + 6]) ? p[j + 6] : '.');
			break;
		case 8:
			MHVTL_DBG_NO_FUNC(lvl,
							  "%02x %02x %02x %02x %02x %02x %02x %02x %24s : %c%c%c%c%c%c%c%c",
							  p[j + 0], p[j + 1], p[j + 2], p[j + 3],
							  p[j + 4], p[j + 5], p[j + 6], p[j + 7],
							  " ",
							  isprint(p[j + 0]) ? p[j + 0] : '.',
							  isprint(p[j + 1]) ? p[j + 1] : '.',
							  isprint(p[j + 2]) ? p[j + 2] : '.',
							  isprint(p[j + 3]) ? p[j + 3] : '.',
							  isprint(p[j + 4]) ? p[j + 4] : '.',
							  isprint(p[j + 5]) ? p[j + 5] : '.',
							  isprint(p[j + 6]) ? p[j + 6] : '.',
							  isprint(p[j + 7]) ? p[j + 7] : '.');
			break;
		case 9:
			MHVTL_DBG_NO_FUNC(lvl,
							  "%02x %02x %02x %02x %02x %02x %02x %02x  %02x %19s : %c%c%c%c%c%c%c%c %c",
							  p[j + 0], p[j + 1], p[j + 2], p[j + 3],
							  p[j + 4], p[j + 5], p[j + 6], p[j + 7],
							  p[j + 8],
							  " ",
							  isprint(p[j + 0]) ? p[j + 0] : '.',
							  isprint(p[j + 1]) ? p[j + 1] : '.',
							  isprint(p[j + 2]) ? p[j + 2] : '.',
							  isprint(p[j + 3]) ? p[j + 3] : '.',
							  isprint(p[j + 4]) ? p[j + 4] : '.',
							  isprint(p[j + 5]) ? p[j + 5] : '.',
							  isprint(p[j + 6]) ? p[j + 6] : '.',
							  isprint(p[j + 7]) ? p[j + 7] : '.',
							  isprint(p[j + 8]) ? p[j + 8] : '.');
			break;
		case 10:
			MHVTL_DBG_NO_FUNC(lvl,
							  "%02x %02x %02x %02x %02x %02x %02x %02x  %02x %02x %16s : %c%c%c%c%c%c%c%c %c%c",
							  p[j + 0], p[j + 1], p[j + 2], p[j + 3],
							  p[j + 4], p[j + 5], p[j + 6], p[j + 7],
							  p[j + 8], p[j + 9],
							  " ",
							  isprint(p[j + 0]) ? p[j + 0] : '.',
							  isprint(p[j + 1]) ? p[j + 1] : '.',
							  isprint(p[j + 2]) ? p[j + 2] : '.',
							  isprint(p[j + 3]) ? p[j + 3] : '.',
							  isprint(p[j + 4]) ? p[j + 4] : '.',
							  isprint(p[j + 5]) ? p[j + 5] : '.',
							  isprint(p[j + 6]) ? p[j + 6] : '.',
							  isprint(p[j + 7]) ? p[j + 7] : '.',
							  isprint(p[j + 8]) ? p[j + 8] : '.',
							  isprint(p[j + 9]) ? p[j + 9] : '.');
			break;
		case 11:
			MHVTL_DBG_NO_FUNC(lvl,
							  "%02x %02x %02x %02x %02x %02x %02x %02x  %02x %02x %02x %13s : %c%c%c%c%c%c%c%c %c%c%c",
							  p[j + 0], p[j + 1], p[j + 2], p[j + 3],
							  p[j + 4], p[j + 5], p[j + 6], p[j + 7],
							  p[j + 8], p[j + 9], p[j + 10],
							  " ",
							  isprint(p[j + 0]) ? p[j + 0] : '.',
							  isprint(p[j + 1]) ? p[j + 1] : '.',
							  isprint(p[j + 2]) ? p[j + 2] : '.',
							  isprint(p[j + 3]) ? p[j + 3] : '.',
							  isprint(p[j + 4]) ? p[j + 4] : '.',
							  isprint(p[j + 5]) ? p[j + 5] : '.',
							  isprint(p[j + 6]) ? p[j + 6] : '.',
							  isprint(p[j + 7]) ? p[j + 7] : '.',
							  isprint(p[j + 8]) ? p[j + 8] : '.',
							  isprint(p[j + 9]) ? p[j + 9] : '.',
							  isprint(p[j + 10]) ? p[j + 10] : '.');
			break;
		case 12:
			MHVTL_DBG_NO_FUNC(lvl,
							  "%02x %02x %02x %02x %02x %02x %02x %02x  %02x %02x %02x %02x %10s : %c%c%c%c%c%c%c%c %c%c%c%c",
							  p[j + 0], p[j + 1], p[j + 2], p[j + 3],
							  p[j + 4], p[j + 5], p[j + 6], p[j + 7],
							  p[j + 8], p[j + 9], p[j + 10], p[j + 11],
							  " ",
							  isprint(p[j + 0]) ? p[j + 0] : '.',
							  isprint(p[j + 1]) ? p[j + 1] : '.',
							  isprint(p[j + 2]) ? p[j + 2] : '.',
							  isprint(p[j + 3]) ? p[j + 3] : '.',
							  isprint(p[j + 4]) ? p[j + 4] : '.',
							  isprint(p[j + 5]) ? p[j + 5] : '.',
							  isprint(p[j + 6]) ? p[j + 6] : '.',
							  isprint(p[j + 7]) ? p[j + 7] : '.',
							  isprint(p[j + 8]) ? p[j + 8] : '.',
							  isprint(p[j + 9]) ? p[j + 9] : '.',
							  isprint(p[j + 10]) ? p[j + 10] : '.',
							  isprint(p[j + 11]) ? p[j + 11] : '.');
			break;
		case 13:
			MHVTL_DBG_NO_FUNC(lvl,
							  "%02x %02x %02x %02x %02x %02x %02x %02x  %02x %02x %02x %02x %02x %8s : %c%c%c%c%c%c%c%c %c%c%c%c%c",
							  p[j + 0], p[j + 1], p[j + 2], p[j + 3],
							  p[j + 4], p[j + 5], p[j + 6], p[j + 7],
							  p[j + 8], p[j + 9], p[j + 10], p[j + 11],
							  p[j + 12],
							  " ",
							  isprint(p[j + 0]) ? p[j + 0] : '.',
							  isprint(p[j + 1]) ? p[j + 1] : '.',
							  isprint(p[j + 2]) ? p[j + 2] : '.',
							  isprint(p[j + 3]) ? p[j + 3] : '.',
							  isprint(p[j + 4]) ? p[j + 4] : '.',
							  isprint(p[j + 5]) ? p[j + 5] : '.',
							  isprint(p[j + 6]) ? p[j + 6] : '.',
							  isprint(p[j + 7]) ? p[j + 7] : '.',
							  isprint(p[j + 8]) ? p[j + 8] : '.',
							  isprint(p[j + 9]) ? p[j + 9] : '.',
							  isprint(p[j + 10]) ? p[j + 10] : '.',
							  isprint(p[j + 11]) ? p[j + 11] : '.',
							  isprint(p[j + 12]) ? p[j + 12] : '.');
			break;
		case 14:
			MHVTL_DBG_NO_FUNC(lvl,
							  "%02x %02x %02x %02x %02x %02x %02x %02x  %02x %02x %02x %02x %02x %02x %5s : %c%c%c%c%c%c%c%c %c%c%c%c%c%c",
							  p[j + 0], p[j + 1], p[j + 2], p[j + 3],
							  p[j + 4], p[j + 5], p[j + 6], p[j + 7],
							  p[j + 8], p[j + 9], p[j + 10], p[j + 11],
							  p[j + 12], p[j + 13],
							  " ",
							  isprint(p[j + 0]) ? p[j + 0] : '.',
							  isprint(p[j + 1]) ? p[j + 1] : '.',
							  isprint(p[j + 2]) ? p[j + 2] : '.',
							  isprint(p[j + 3]) ? p[j + 3] : '.',
							  isprint(p[j + 4]) ? p[j + 4] : '.',
							  isprint(p[j + 5]) ? p[j + 5] : '.',
							  isprint(p[j + 6]) ? p[j + 6] : '.',
							  isprint(p[j + 7]) ? p[j + 7] : '.',
							  isprint(p[j + 8]) ? p[j + 8] : '.',
							  isprint(p[j + 9]) ? p[j + 9] : '.',
							  isprint(p[j + 10]) ? p[j + 10] : '.',
							  isprint(p[j + 11]) ? p[j + 11] : '.',
							  isprint(p[j + 12]) ? p[j + 12] : '.',
							  isprint(p[j + 13]) ? p[j + 13] : '.');
			break;
		case 15:
			MHVTL_DBG_NO_FUNC(lvl,
							  "%02x %02x %02x %02x %02x %02x %02x %02x  %02x %02x %02x %02x %02x %02x %02x %2s : %c%c%c%c%c%c%c%c %c%c%c%c%c%c%c",
							  p[j + 0], p[j + 1], p[j + 2], p[j + 3],
							  p[j + 4], p[j + 5], p[j + 6], p[j + 7],
							  p[j + 8], p[j + 9], p[j + 10], p[j + 11],
							  p[j + 12], p[j + 13], p[j + 14],
							  " ",
							  isprint(p[j + 0]) ? p[j + 0] : '.',
							  isprint(p[j + 1]) ? p[j + 1] : '.',
							  isprint(p[j + 2]) ? p[j + 2] : '.',
							  isprint(p[j + 3]) ? p[j + 3] : '.',
							  isprint(p[j + 4]) ? p[j + 4] : '.',
							  isprint(p[j + 5]) ? p[j + 5] : '.',
							  isprint(p[j + 6]) ? p[j + 6] : '.',
							  isprint(p[j + 7]) ? p[j + 7] : '.',
							  isprint(p[j + 8]) ? p[j + 8] : '.',
							  isprint(p[j + 9]) ? p[j + 9] : '.',
							  isprint(p[j + 10]) ? p[j + 10] : '.',
							  isprint(p[j + 11]) ? p[j + 11] : '.',
							  isprint(p[j + 12]) ? p[j + 12] : '.',
							  isprint(p[j + 13]) ? p[j + 13] : '.',
							  isprint(p[j + 14]) ? p[j + 14] : '.');
			break;
		default:
			MHVTL_DBG_NO_FUNC(lvl,
							  "%02x %02x %02x %02x %02x %02x %02x %02x  %02x %02x %02x %02x %02x %02x %02x %02x : %c%c%c%c%c%c%c%c %c%c%c%c%c%c%c%c",
							  p[j + 0], p[j + 1], p[j + 2], p[j + 3],
							  p[j + 4], p[j + 5], p[j + 6], p[j + 7],
							  p[j + 8], p[j + 9], p[j + 10], p[j + 11],
							  p[j + 12], p[j + 13], p[j + 14], p[j + 15],
							  isprint(p[j + 0]) ? p[j + 0] : '.',
							  isprint(p[j + 1]) ? p[j + 1] : '.',
							  isprint(p[j + 2]) ? p[j + 2] : '.',
							  isprint(p[j + 3]) ? p[j + 3] : '.',
							  isprint(p[j + 4]) ? p[j + 4] : '.',
							  isprint(p[j + 5]) ? p[j + 5] : '.',
							  isprint(p[j + 6]) ? p[j + 6] : '.',
							  isprint(p[j + 7]) ? p[j + 7] : '.',
							  isprint(p[j + 8]) ? p[j + 8] : '.',
							  isprint(p[j + 9]) ? p[j + 9] : '.',
							  isprint(p[j + 10]) ? p[j + 10] : '.',
							  isprint(p[j + 11]) ? p[j + 11] : '.',
							  isprint(p[j + 12]) ? p[j + 12] : '.',
							  isprint(p[j + 13]) ? p[j + 13] : '.',
							  isprint(p[j + 14]) ? p[j + 14] : '.',
							  isprint(p[j + 15]) ? p[j + 15] : '.');
			break;
		}
	}
}

static int mhvtl_access(char *p, int len, char *entry) {
	int			fstat;
	struct stat km;
	char		filename[256];

	snprintf(filename, ARRAY_SIZE(filename),
			 "/sys/bus/mhvtl/drivers/mhvtl/%s", entry);
	MHVTL_DBG(1, "Testing %s", filename);
	fstat = stat(filename, &km);
	if (fstat >= 0) {
		strncpy(p, filename, len);
		return 0;
	}
	snprintf(filename, ARRAY_SIZE(filename),
			 "/sys/bus/pseudo9/drivers/mhvtl/%s", entry);
	MHVTL_DBG(1, "Testing %s", filename);
	fstat = stat(filename, &km);
	if (fstat >= 0) {
		strncpy(p, filename, len);
		return 0;
	}
	snprintf(filename, ARRAY_SIZE(filename),
			 "/sys/bus/pseudo/drivers/mhvtl/%s", entry);
	MHVTL_DBG(1, "Testing %s", filename);
	fstat = stat(filename, &km);
	if (fstat >= 0) {
		strncpy(p, filename, len);
		return 0;
	}
	return -1;
}

/* Writing to the kernel module will block until the device is created.
 * Unfortunately, we need to be polling the device and process the
 * SCSI op code before the lu can be created.
 * Chicken & Egg.
 * So spawn child process and don't wait for return.
 * Let the child process write to the kernel module
 */
pid_t add_lu(unsigned minor, struct mhvtl_ctl *ctl) {
	char	str[1024];
	pid_t	ppid, pid, mypid;
	ssize_t retval;
	FILE   *pseudo;
	char	pseudo_filename[256];
	char	errmsg[512];

	sprintf(str, "add %u %d %d %d",
			minor, ctl->channel, ctl->id, ctl->lun);

	if (mhvtl_access(pseudo_filename, ARRAY_SIZE(pseudo_filename), "add_lu") < 0) {
		sprintf(str, "Could not find mhvtl kernel module");
		MHVTL_ERR("%s: %s", mhvtl_driver_name, str);
		printf("%s: %s\n", mhvtl_driver_name, str);
		exit(EIO);
	}

	/* Parent PID */
	ppid = getpid();

	switch (pid = fork()) {
	case 0: /* Child */
		mypid  = getpid();
		pseudo = fopen(pseudo_filename, "w");
		if (!pseudo) {
			snprintf(errmsg, ARRAY_SIZE(errmsg),
					 "Could not open %s: %s", pseudo_filename, strerror(errno));
			MHVTL_ERR("Parent PID: %ld -> %s : %s", (long)ppid, errmsg, strerror(errno));
			perror("Could not open 'add_lu'");
			exit(-1);
		}

		retval = fprintf(pseudo, "%s\n", str);
		MHVTL_DBG(2, "Wrote '%s' (%d bytes) to %s",
				  str, (int)retval, pseudo_filename);

		fclose(pseudo);
		MHVTL_DBG(1, "Parent PID: [%ld] -> Child [%ld] anounces 'lu [%d:%d:%d] created'.",
				  (long)ppid, (long)mypid, ctl->channel, ctl->id, ctl->lun);
		exit(0);
		break;
	case -1:
		perror("Failed to fork()");
		MHVTL_ERR("Parent PID: %ld -> Fail to fork() %s", (long)ppid, strerror(errno));
		return 0;
		break;
	default: /* Parent */
		MHVTL_DBG(2, "[%ld] Child PID [%ld] will start logical unit [%d:%d:%d]",
				  (long)ppid, (long)pid, ctl->channel,
				  ctl->id, ctl->lun);

		return pid;
		break;
	}

	return 0;
}

static int chrdev_get_major(void) {
	FILE	  *f;
	char	   filename[256];
	const char str[] = "Could not locate mhvtl kernel module";
	int		   rc	 = 0;
	int		   x;
	int		   majno;

	if (mhvtl_access(filename, ARRAY_SIZE(filename), "major") < 0) {
		MHVTL_ERR("%s: %s", mhvtl_driver_name, str);
		printf("%s: %s\n", mhvtl_driver_name, str);
		exit(EIO);
	}

	f = fopen(filename, "r");
	if (!f) {
		MHVTL_DBG(1, "Can't open %s: %s", filename, strerror(errno));
		return -ENOENT;
	}
	x = fscanf(f, "%d", &majno);
	if (!x) {
		MHVTL_DBG(1, "Cant identify major number for mhvtl");
		rc = -1;
	} else
		rc = majno;

	fclose(f);
	return rc;
}

int chrdev_create(unsigned minor) {
	int	  majno;
	int	  x;
	int	  ret = 0;
	dev_t dev;
	char  pathname[64];

	snprintf(pathname, sizeof(pathname), "/dev/mhvtl%u", minor);

	majno = chrdev_get_major();
	if (majno == -ENOENT) {
		MHVTL_DBG(1, "** Incorrect version of kernel module loaded **");
		ret = -1;
		goto err;
	}

	dev = makedev(majno, minor);
	MHVTL_DBG(2, "Major number: %d, minor number: %u",
			  major(dev), minor(dev));
	MHVTL_DBG(3, "mknod(%s, %02o, major: %d minor: %d",
			  pathname, S_IFCHR | S_IRUSR | S_IWUSR | S_IRGRP | S_IWGRP,
			  major(dev), minor(dev));
	x = mknod(pathname, S_IFCHR | S_IRUSR | S_IWUSR | S_IRGRP | S_IWGRP, dev);
	if (x < 0) {
		if (errno == EEXIST) /* Success if node already exists */
			return 0;

		MHVTL_DBG(1, "Error creating device node for mhvtl: %s",
				  strerror(errno));
		ret = -1;
	}

err:
	return ret;
}

int chrdev_open(const char *name, unsigned minor) {
	FILE *f;
	char  devname[256];
	char  buf[256];
	int	  devn;
	int	  ctlfd;

	f = fopen("/proc/devices", "r");
	if (!f) {
		printf("Cannot open control path to the driver: %s\n",
			   strerror(errno));
		return -1;
	}

	devn = 0;
	while (!feof(f)) {
		if (!fgets(buf, sizeof(buf), f))
			break;
		if (sscanf(buf, "%d %s", &devn, devname) != 2)
			continue;
		if (!strcmp(devname, name))
			break;
		devn = 0;
	}
	fclose(f);
	if (!devn) {
		printf("Cannot find %s in /proc/devices - "
			   "make sure the module is loaded\n",
			   name);
		return -1;
	}
	snprintf(devname, sizeof(devname), "/dev/%s%u", name, minor);
	ctlfd = open(devname, O_RDWR | O_NONBLOCK | O_EXCL);
	if (ctlfd < 0) {
		printf("Cannot open %s %s\n", devname, strerror(errno));
		fflush(NULL);
		printf("\n\n");
		return -1;
	}
	return ctlfd;
}

/* Create the fifo and open it for writing (appending)
 * Return 0 on success,
 * Return errno on failure
 */
int open_fifo(FILE **fifo_fd, char *fifoname) {
	int ret;

	umask(0);
	ret = 0;

	ret = mknod(fifoname, S_IFIFO | 0644, 0);
	if ((ret < 0) && (errno != EEXIST)) {
		MHVTL_LOG("Sorry, cant create %s: %s, Disabling fifo feature",
				  fifoname, strerror(errno));
		ret = errno;
	} else {
		*fifo_fd = fopen(fifoname, "w+");
		if (*fifo_fd) {
			MHVTL_DBG(2, "Successfully opened named pipe: %s",
					  fifoname);
		} else {
			MHVTL_LOG("Sorry, cant open %s: %s, "
					  "Disabling fifo feature",
					  fifoname, strerror(errno));
			ret = errno;
		}
	}
	return ret;
}

void status_change(FILE *fifo_fd, int current_status, int m_id, char **msg) {
	time_t	 t;
	char	*timestamp;
	unsigned i;

	if (!fifo_fd)
		return;

	t		  = time(NULL);
	timestamp = ctime(&t);

	for (i = 14; i < strlen(timestamp); i++)
		if (timestamp[i] == '\n')
			timestamp[i] = '\0';

	if (*msg) {
		fprintf(fifo_fd, "%s - %d: - %s\n",
				timestamp, m_id, *msg);
		free(*msg);
		*msg = NULL;
	} else
		fprintf(fifo_fd, "%s - %d: - %s\n", timestamp, m_id,
				state_desc[current_status].state_desc);

	fflush_unlocked(fifo_fd);

	return;
}

/*
 * Pinched straight from SCSI tgt code
 * Thanks guys..
 *
 * Modified to always return success. Earlier kernels don't have oom_adjust
 * 'feature' so don't fail if we can't find it..
 */
int oom_adjust(void) {
	int	 fd, ret;
	char path[64];

	/* Avoid oom-killer */
	sprintf(path, "/proc/%d/oom_score_adj", getpid());
	fd = open(path, O_WRONLY);
	if (fd < 0) {
		MHVTL_DBG(3, "Can't open oom-killer's pardon %s, %s",
				  path, strerror(errno));
		return 0;
	}
	ret = write(fd, "-17\n", 4);
	if (ret < 0) {
		MHVTL_DBG(3, "Can't adjust oom-killer's pardon %s, %s",
				  path, strerror(errno));
	}
	close(fd);
	return 0;
}

/* fgets but replace '\n' with null */
char *readline(char *buf, int len, FILE *s) {
	int	  i;
	char *ret;

	ret = fgets(buf, len, s);
	if (!ret)
		return ret;

	/* Skip blank line */
	for (i = 1; i < len; i++)
		if (buf[i] == '\n')
			buf[i] = 0;

	MHVTL_DBG(3, "%s", buf);
	return ret;
}

/* Copy bytes from 'src' to 'dest, blank-filling to length 'len'.  There will
 * not be a NULL byte at the end.
 */
void blank_fill(uint8_t *dest, char *src, int len) {
	int i;

	for (i = 0; i < len; i++) {
		if (*src != '\0')
			*dest++ = *src++;
		else
			*dest++ = ' ';
	}
}

void truncate_spaces(char *s, int maxlen) {
	int x;

	for (x = 0; x < maxlen; x++)
		if ((s[x] == ' ') || (s[x] == '\0')) {
			s[x] = '\0';
			return;
		}
}

/* MHVTL_VERSION looks like : 0.18.xx or 1.xx.xx
 *
 * Convert into a string after converting the 18.xx into "18xx"
 *
 * NOTE: Caller has to free string after use.
 */
char *get_version(void) {
	char  b[64];
	int	  x, y, z;
	char *c;

	c = (char *)zalloc(32); /* Way more than enough for a 4 byte string */
	if (!c)
		return NULL;

	sprintf(b, "%s", MHVTL_VERSION);

	sscanf(b, "%d.%d.%d", &x, &y, &z);
	if (x)
		sprintf(c, "%02d%02d", x, y);
	else
		sprintf(c, "%02d%02d", y, z);

	return c;
}

void log_opcode(char *opcode, struct scsi_cmd *cmd) {
	struct s_sd sd;

	MHVTL_DBG(1, "*** Unsupported op code: %s ***", opcode);
	sd.byte0		 = SKSV | CD;
	sd.field_pointer = 0;
	sam_illegal_request(E_INVALID_OP_CODE, &sd, &cmd->dbuf_p->sam_stat);
	MHVTL_DBG_PRT_CDB(1, cmd);
}

#define LOCK_PATH "/var/lock/mhvtl"
#define MAX_WAIT  20
int check_for_running_daemons(unsigned minor) {
	char lck_file[128];
	int	 lck;
	int	 a;
	long rand;

	/* Don't really care if this dir exists already */
	if (mkdir(LOCK_PATH, S_IWUSR | S_IRUSR) < 0) {
		MHVTL_DBG(3, "Unable to create lock directory %s", LOCK_PATH);
	}

	sprintf(lck_file, "%s/mhvtl%d", LOCK_PATH, minor);
	MHVTL_DBG(1, "Checking lock file %s", lck_file);

	for (a = 0; a < MAX_WAIT; a++) {
		lck = open(lck_file, O_CREAT | O_EXCL | O_WRONLY, S_IRWXU);
		if (lck >= 0) {
			MHVTL_DBG(1, "Successfully created lock file %s", lck_file);
			close(lck);
			return 0;
		} else if (errno == EEXIST) { /* Lock file still exists */
			rand = (0xffL & random()) << 12;
			MHVTL_DBG(3, "Lock file exists, sleeping for 0x%lxs", rand);
			usleep((useconds_t)rand);
		} else { /* Unexpected error */
			MHVTL_DBG(1, "opening lock file %s failed %s", lck_file, strerror(errno));
			return 2;
		}
	}

	MHVTL_DBG(1, "Unable to obtain lock file %s - returing error", lck_file);
	return 1;
}

int free_lock(unsigned minor) {
	char lck_file[128];

	sprintf(lck_file, "%s/mhvtl%d", LOCK_PATH, minor);
	MHVTL_DBG(1, "Unlink %s", lck_file);
	unlink(lck_file);
	return 0;
}

/* Abort if string length > len */
void checkstrlen(char *s, unsigned int len, int lineno) {
	if (strlen(s) > len) {
		MHVTL_DBG(1, "Line #: %d, String %s is > %d... Aborting",
				  lineno, s, len);
		printf("String %s longer than %d chars\n", s, len);
		printf("Please fix config file\n");
		abort();
	}
}

int device_type_register(struct lu_phy_attr *lu, struct device_type_template *t) {
	lu->scsi_ops = t;
	return 0;
}

uint8_t set_compression_mode_pg(struct list_head *l, int lvl) {
	struct mode *m;
	uint8_t		*p;

	MHVTL_DBG(3, "*** Trace ***");

	/* Find pointer to Data Compression mode Page */
	m = lookup_mode_pg(l, MODE_DATA_COMPRESSION, 0);
	MHVTL_DBG(3, "l: %p, m: %p, m->pcodePointer: %p",
			  l, m, m->pcodePointer);
	if (m) {
		p = m->pcodePointer;
		p[2] |= 0x80; /* Set data compression enable */
	}
	/* Find pointer to Device Configuration mode Page */
	m = lookup_mode_pg(l, MODE_DEVICE_CONFIGURATION, 0);
	MHVTL_DBG(3, "l: %p, m: %p, m->pcodePointer: %p",
			  l, m, m->pcodePointer);
	if (m) {
		p	  = m->pcodePointer;
		p[14] = lvl;
	}
	return SAM_STAT_GOOD;
}

uint8_t clear_compression_mode_pg(struct list_head *l) {
	struct mode *m;
	uint8_t		*p;

	MHVTL_DBG(3, "*** Trace ***");

	/* Find pointer to Data Compression mode Page */
	m = lookup_mode_pg(l, MODE_DATA_COMPRESSION, 0);
	MHVTL_DBG(3, "l: %p, m: %p, m->pcodePointer: %p",
			  l, m, m->pcodePointer);
	if (m) {
		p = m->pcodePointer;
		p[2] &= 0x7f; /* clear data compression enable */
	}
	/* Find pointer to Device Configuration mode Page */
	m = lookup_mode_pg(l, MODE_DEVICE_CONFIGURATION, 0);
	MHVTL_DBG(3, "l: %p, m: %p, m->pcodePointer: %p",
			  l, m, m->pcodePointer);
	if (m) {
		p	  = m->pcodePointer;
		p[14] = MHVTL_NO_COMPRESSION;
	}
	return SAM_STAT_GOOD;
}

uint8_t clear_WORM(struct list_head *l) {
	uint8_t		*smp_dp;
	struct mode *m;

	m = lookup_mode_pg(l, MODE_MEDIUM_CONFIGURATION, 0);
	if (!m) {
		MHVTL_DBG(3, "Did not find MODE_MEDIUM_CONFIGURATION page");
	} else {
		MHVTL_DBG(3, "l: %p, m: %p, m->pcodePointer: %p",
				  l, m, m->pcodePointer);

		smp_dp = m->pcodePointer;
		if (!smp_dp)
			return SAM_STAT_GOOD;
		smp_dp[2] = 0x0;
	}

	return SAM_STAT_GOOD;
}

uint8_t set_WORM(struct list_head *l) {
	uint8_t		*smp_dp;
	struct mode *m;

	MHVTL_DBG(3, "*** Trace ***");

	m = lookup_mode_pg(l, MODE_MEDIUM_CONFIGURATION, 0);
	if (!m) {
		MHVTL_DBG(3, "Did not find MODE_MEDIUM_CONFIGURATION page");
	} else {
		MHVTL_DBG(3, "l: %p, m: %p, m->pcodePointer: %p",
				  l, m, m->pcodePointer);

		smp_dp = m->pcodePointer;
		if (!smp_dp)
			return SAM_STAT_GOOD;
		smp_dp[2] = 0x10;
		smp_dp[4] = 0x01; /* Indicate label overwrite */
	}

	return SAM_STAT_GOOD;
}

/* Remove newline from string and fill rest of 'len' with char 'c' */
void rmnl(char *s, unsigned char c, int len) {
	int i;
	int found = 0;

	for (i = 0; i < len; i++) {
		if (s[i] == '\n')
			found = 1;
		if (found)
			s[i] = c;
	}
}

void update_vpd_86(struct lu_phy_attr *lu, void *p) {
	struct vpd *vpd_pg = lu->lu_vpd[PCODE_OFFSET(0x86)];

	struct ssc_personality_template *spt;

	spt = p;

	MHVTL_DBG(1, "SPT is : 0x%02x", spt->drive_supports_LBP);

	vpd_pg->data[0] = (spt->drive_supports_LBP) ? 0x8 : 0;

	vpd_pg->data[1] = 0x01; /* SIMPSUP (Device supports simple queing) */
}

void update_vpd_b0(struct lu_phy_attr *lu, void *p) {
	struct vpd *vpd_pg = lu->lu_vpd[PCODE_OFFSET(0xb0)];
	uint8_t	   *worm;

	worm = (uint8_t *)p;

	*vpd_pg->data = (*worm) ? 1 : 0; /* Set WORM bit */
}

void update_vpd_b1(struct lu_phy_attr *lu, void *p) {
	struct vpd *vpd_pg = lu->lu_vpd[PCODE_OFFSET(0xb1)];

	memcpy(vpd_pg->data, p, vpd_pg->sz);
}

void update_vpd_b2(struct lu_phy_attr *lu, void *p) {
	struct vpd *vpd_pg = lu->lu_vpd[PCODE_OFFSET(0xb2)];

	memcpy(vpd_pg->data, p, vpd_pg->sz);
}

/* VPD 0xB5 */
void update_vpd_lbp(struct lu_phy_attr *lu, void *p) {
	struct vpd *vpd_pg = lu->lu_vpd[PCODE_OFFSET(0xb2)];

	memcpy(vpd_pg->data, p, vpd_pg->sz);
}

void update_vpd_c0(struct lu_phy_attr *lu, void *p) {
	struct vpd *vpd_pg = lu->lu_vpd[PCODE_OFFSET(0xc0)];

	memcpy(&vpd_pg->data[20], p, strlen((const char *)p));
}

void update_vpd_c1(struct lu_phy_attr *lu, void *p) {
	struct vpd *vpd_pg = lu->lu_vpd[PCODE_OFFSET(0xc1)];

	memcpy(vpd_pg->data, p, vpd_pg->sz);
}

void cleanup_density_support(struct list_head *l) {
	struct supported_density_list *dp, *ndp;

	list_for_each_entry_safe(dp, ndp, l, siblings) {
		list_del(&dp->siblings);
		free(dp);
	}
}

int add_density_support(struct list_head *l, struct density_info *di, int rw) {
	struct supported_density_list *supported;

	supported = zalloc(sizeof(struct supported_density_list));
	if (!supported)
		return -ENOMEM;

	supported->density_info = di;
	supported->rw			= rw;
	list_add_tail(&supported->siblings, l);
	return 0;
}

void process_fifoname(struct lu_phy_attr *lu, char *s, int flag) {
	MHVTL_DBG(3, "entry: %s, flag: %d, existing name: %s",
			  s, flag, lu->fifoname);
	if (lu->fifo_flag) /* fifo set via '-f <fifo>' switch */
		return;
	checkstrlen(s, MALLOC_SZ - 1, 0);
	free(lu->fifoname);
	lu->fifoname = (char *)zalloc(strlen(s) + 2);
	if (!lu->fifoname) {
		printf("Unable to malloc fifo buffer");
		exit(-ENOMEM);
	}
	lu->fifo_flag = flag;
	/* Already checked for sane length */
	strcpy(lu->fifoname, s);
}

/* Remove message queue */
void cleanup_msg(void) {
	int				msqid;
	int				retval;
	struct msqid_ds ds;

	msqid = init_queue();
	if (msqid < 0) {
		MHVTL_ERR("Failed to open msg queue: %s", strerror(errno));
		return;
	}
	retval = msgctl(msqid, IPC_RMID, &ds);
	if (retval < 0) {
		MHVTL_ERR("Failed to remove msg queue: %s", strerror(errno));
	} else {
		MHVTL_DBG(2, "Removed ipc resources");
	}
}

#define QUERYSHM 0
#define INCSHM	 1
#define DECSHM	 2

static int mhvtl_shared_mem(int flag) {
	int				mhvtl_shm;
	int				retval = -1;
	int			   *base;
	key_t			key;
	struct shmid_ds buf;

	key = 0x4d61726b;

	mhvtl_shm = shmget(key, 16, IPC_CREAT | 0666);
	if (mhvtl_shm < 0) {
		printf("Attempt to get Shared memory failed\n");
		MHVTL_ERR("Attempt to get shared memory failed");
		return -ENOMEM;
	}

	base = (int *)shmat(mhvtl_shm, NULL, 0);
	if (base == (void *)-1) {
		MHVTL_ERR("Failed to attach to shm: %s", strerror(errno));
		return -1;
	}

	MHVTL_DBG(3, "[%d] shm count is: %d", (int)getpid(), *base);

	switch (flag) {
	case QUERYSHM:
		break;
	case INCSHM:
		(*base)++;
		break;
	case DECSHM:
		if (*base)
			(*base)--;

		/* No more consumers - mark as remove */
		if (*base == 0) {
			shmctl(mhvtl_shm, IPC_STAT, &buf);
			shmctl(mhvtl_shm, IPC_RMID, &buf);
			MHVTL_DBG(3, "pid of creator: %d,"
						 " pid of last shmat(): %d, "
						 " Number of current attach: %d",
					  buf.shm_cpid,
					  buf.shm_lpid,
					  (int)buf.shm_nattch);
			/* Should be no more users of the message Q either */
			cleanup_msg();
		}
		break;
	}
	MHVTL_DBG(3, "[%d] shm count now: %d", (int)getpid(), *base);

	retval = *base;

	shmdt(base);

	return retval;
}

static int mhvtl_fifo_count(int direction) {
	sem_t *mhvtl_sem;
	int	   sval;
	int	   i;
	char   errmsg[] = "mhvtl_sem";
	int	   retval	= -1;

	mhvtl_sem = sem_open("/mhVTL", O_CREAT, 0664, 1);
	if (SEM_FAILED == mhvtl_sem) {
		MHVTL_ERR("%s : %s", errmsg, strerror(errno));
		return retval;
	}

	sem_getvalue(mhvtl_sem, &sval);
	for (i = 0; i < 10; i++) {
		if (sem_trywait(mhvtl_sem)) {
			MHVTL_LOG("Waiting for semaphore: %p", mhvtl_sem);
			sleep(1);
			if (i > 8) {
				/* Give up.. Clear the semaphore & do it */
				MHVTL_ERR("waiting for semaphore: %p",
						  mhvtl_sem);
				sem_post(mhvtl_sem);
			}
		} else {
			retval = mhvtl_shared_mem(direction);
			sem_post(mhvtl_sem);
			break;
		}
	}

	sem_close(mhvtl_sem);
	return retval;
}

int dec_fifo_count(void) {
	return mhvtl_fifo_count(DECSHM);
}

int inc_fifo_count(void) {
	return mhvtl_fifo_count(INCSHM);
}

int get_fifo_count(void) {
	return mhvtl_fifo_count(QUERYSHM);
}

/*
 * find the mhvtl home directory and the library ID supplied in the device.conf
 * file from our config directory. Use the default config directory unless one
 * is passed in
 */
void find_media_home_directory(char *config_directory, long lib_id) {
	char  device_conf[CONF_FILE_SZ];
	FILE *conf;
	char *b; /* Read from file into this buffer */
	char *s; /* Somewhere for sscanf to store results */
	long  i;
	int	  found;

	found			  = 0;
	home_directory[0] = '\0';

	if (config_directory) {
		snprintf(device_conf, CONF_FILE_SZ, "%s/device.conf", config_directory);
	} else if (get_config(device_conf, DEVICE_CONF, my_id) < 0) {
		exit(1);
	}

	conf = fopen(device_conf, "r");
	if (!conf) {
		MHVTL_ERR("Can not open config file %s : %s", device_conf,
				  strerror(errno));
		perror("Can not open config file");
		exit(1);
	}
	s = zalloc(MALLOC_SZ);
	if (!s) {
		perror("Could not allocate memory");
		exit(1);
	}
	b = zalloc(MALLOC_SZ);
	if (!b) {
		perror("Could not allocate memory");
		exit(1);
	}
	while (readline(b, MALLOC_SZ, conf) != NULL) {
		if (b[0] == '#') /* Ignore comments */
			continue;
		if (strlen(b) < 3) /* Reset drive number of blank line */
			i = 0xff;
		if (sscanf(b, "Library: %ld ", &i)) {
			MHVTL_DBG(2, "Found Library %ld, looking for %ld",
					  i, lib_id);
			if (i == lib_id)
				found = 1;
		}
		if (found == 1) {
			int a;
			a = sscanf(b, " Home directory: %s", s);
			if (a > 0) {
				strncpy(home_directory, s, HOME_DIR_PATH_SZ);
				MHVTL_DBG(2, "Found home directory  : %s",
						  home_directory);
				goto finished; /* Found what we came for */
			}
		}
	}

	/* Not found, then append the library id to default path */
	snprintf(home_directory, HOME_DIR_PATH_SZ, "%s/%ld",
			 MHVTL_HOME_PATH, lib_id);
	MHVTL_DBG(1, "Append library id %ld to default path %s: %s",
			  lib_id, MHVTL_HOME_PATH,
			  home_directory);

finished:
	free(s);
	free(b);
	fclose(conf);
}

unsigned int set_media_params(struct MAM *mamp, char *density) {
	/* Invent some defaults */
	mamp->MediaType = Media_undefined;
	put_unaligned_be32(2048, &mamp->media_info.bits_per_mm);
	put_unaligned_be16(1, &mamp->media_info.tracks);
	put_unaligned_be32(127, &mamp->MediumWidth);
	put_unaligned_be32(1024, &mamp->MediumLength);
	memcpy(&mamp->media_info.description, "mhvtl", 5);
	mamp->max_partitions = 1;
	mamp->num_partitions = 1;

	if (!(strncmp(density, "LTO1", 4))) {
		mamp->MediumDensityCode = medium_density_code_lto1;
		mamp->MediaType			= Media_LTO1;
		put_unaligned_be32(384, &mamp->MediumLength);
		put_unaligned_be32(127, &mamp->MediumWidth);
		memcpy(&mamp->media_info.description, "Ultrium 1/8T", 12);
		memcpy(&mamp->media_info.density_name, "U-18  ", 6);
		memcpy(&mamp->AssigningOrganization_1, "LTO-CVE", 7);
		put_unaligned_be32(4880, &mamp->media_info.bits_per_mm);
	} else if (!(strncmp(density, "LTO2", 4))) {
		mamp->MediumDensityCode = medium_density_code_lto2;
		mamp->MediaType			= Media_LTO2;
		put_unaligned_be32(512, &mamp->MediumLength);
		put_unaligned_be32(127, &mamp->MediumWidth);
		memcpy(&mamp->media_info.description, "Ultrium 2/8T", 12);
		memcpy(&mamp->media_info.density_name, "U-28  ", 6);
		memcpy(&mamp->AssigningOrganization_1, "LTO-CVE", 7);
		put_unaligned_be32(7398, &mamp->media_info.bits_per_mm);
	} else if (!(strncmp(density, "LTO3", 4))) {
		mamp->MediumDensityCode = medium_density_code_lto3;
		mamp->MediaType			= Media_LTO3;
		put_unaligned_be32(704, &mamp->MediumLength);
		put_unaligned_be32(127, &mamp->MediumWidth);
		memcpy(&mamp->media_info.description, "Ultrium 3/16T", 13);
		memcpy(&mamp->media_info.density_name, "U-316 ", 6);
		memcpy(&mamp->AssigningOrganization_1, "LTO-CVE", 7);
		put_unaligned_be32(9638, &mamp->media_info.bits_per_mm);
	} else if (!(strncmp(density, "LTO4", 4))) {
		mamp->MediumDensityCode = medium_density_code_lto4;
		mamp->MediaType			= Media_LTO4;
		put_unaligned_be32(896, &mamp->MediumLength);
		put_unaligned_be32(127, &mamp->MediumWidth);
		memcpy(&mamp->media_info.description, "Ultrium 4/16T", 13);
		memcpy(&mamp->media_info.density_name, "U-416  ", 6);
		memcpy(&mamp->AssigningOrganization_1, "LTO-CVE", 7);
		put_unaligned_be32(12725, &mamp->media_info.bits_per_mm);
	} else if (!(strncmp(density, "LTO5", 4))) {
		mamp->MediumDensityCode = medium_density_code_lto5;
		mamp->MediaType			= Media_LTO5;
		put_unaligned_be32(1280, &mamp->MediumLength);
		put_unaligned_be32(127, &mamp->MediumWidth);
		memcpy(&mamp->media_info.description, "Ultrium 5/16T", 13);
		memcpy(&mamp->media_info.density_name, "U-516  ", 6);
		memcpy(&mamp->AssigningOrganization_1, "LTO-CVE", 7);
		put_unaligned_be32(15142, &mamp->media_info.bits_per_mm);
		mamp->max_partitions = 2;
		mamp->num_partitions = 2;
	} else if (!(strncmp(density, "LTO6", 4))) {
		mamp->MediumDensityCode = medium_density_code_lto6;
		mamp->MediaType			= Media_LTO6;
		put_unaligned_be32(2176, &mamp->MediumLength);
		put_unaligned_be32(127, &mamp->MediumWidth);
		memcpy(&mamp->media_info.description, "Ultrium 6/16T", 13);
		memcpy(&mamp->media_info.density_name, "U-616  ", 6);
		memcpy(&mamp->AssigningOrganization_1, "LTO-CVE", 7);
		put_unaligned_be32(18441, &mamp->media_info.bits_per_mm);
		mamp->max_partitions = 2;
		mamp->num_partitions = 2;
	} else if (!(strncmp(density, "LTO7", 4))) {
		mamp->MediumDensityCode = medium_density_code_lto7;
		mamp->MediaType			= Media_LTO7;
		put_unaligned_be32(960, &mamp->MediumLength);
		put_unaligned_be32(127, &mamp->MediumWidth);
		memcpy(&mamp->media_info.description, "Ultrium 7/32T", 13);
		memcpy(&mamp->media_info.density_name, "U-732  ", 6);
		memcpy(&mamp->AssigningOrganization_1, "LTO-CVE", 7);
		put_unaligned_be32(19107, &mamp->media_info.bits_per_mm);
		mamp->max_partitions = 2;
		mamp->num_partitions = 2;
	} else if (!(strncmp(density, "LTO8", 4))) {
		mamp->MediumDensityCode = medium_density_code_lto8;
		mamp->MediaType			= Media_LTO8;
		put_unaligned_be32(960, &mamp->MediumLength);
		put_unaligned_be32(127, &mamp->MediumWidth);
		memcpy(&mamp->media_info.description, "Ultrium 8/32T", 13);
		memcpy(&mamp->media_info.density_name, "U-832  ", 6);
		memcpy(&mamp->AssigningOrganization_1, "LTO-CVE", 7);
		put_unaligned_be32(19107, &mamp->media_info.bits_per_mm);
		mamp->max_partitions = 2;
		mamp->num_partitions = 2;
	} else if (!(strncmp(density, "LTO9", 4))) {
		mamp->MediumDensityCode = medium_density_code_lto9;
		mamp->MediaType			= Media_LTO9;
		put_unaligned_be32(960, &mamp->MediumLength);
		put_unaligned_be32(127, &mamp->MediumWidth);
		memcpy(&mamp->media_info.description, "Ultrium 9/32T", 13);
		memcpy(&mamp->media_info.density_name, "U-932  ", 6);
		memcpy(&mamp->AssigningOrganization_1, "LTO-CVE", 7);
		put_unaligned_be32(19107, &mamp->media_info.bits_per_mm);
		mamp->max_partitions = 2;
		mamp->num_partitions = 2;
	} else if (!(strncmp(density, "AIT1", 4))) {
		/* Vaules for AIT taken from "Product Manual SDX-900V v1.0" */
		mamp->MediumDensityCode = medium_density_code_ait1;
		mamp->MediaType			= Media_AIT1;
		put_unaligned_be32(384, &mamp->MediumLength);
		put_unaligned_be32(0x50, &mamp->MediumWidth);
		memcpy(&mamp->media_info.description, "AdvIntelligentTape1", 20);
		memcpy(&mamp->media_info.density_name, "AIT-1 ", 6);
		memcpy(&mamp->AssigningOrganization_1, "SONY", 4);
		put_unaligned_be32(0x11d7, &mamp->media_info.bits_per_mm);
	} else if (!(strncmp(density, "AIT2", 4))) {
		mamp->MediumDensityCode = medium_density_code_ait2;
		mamp->MediaType			= Media_AIT2;
		put_unaligned_be32(384, &mamp->MediumLength);
		put_unaligned_be32(0x50, &mamp->MediumWidth);
		memcpy(&mamp->media_info.description, "AdvIntelligentTape2", 20);
		memcpy(&mamp->media_info.density_name, "AIT-2  ", 6);
		memcpy(&mamp->AssigningOrganization_1, "SONY", 4);
		put_unaligned_be32(0x17d6, &mamp->media_info.bits_per_mm);
	} else if (!(strncmp(density, "AIT3", 4))) {
		mamp->MediumDensityCode = medium_density_code_ait3;
		mamp->MediaType			= Media_AIT3;
		put_unaligned_be32(384, &mamp->MediumLength);
		put_unaligned_be32(0x50, &mamp->MediumWidth);
		memcpy(&mamp->media_info.description, "AdvIntelligentTape3", 20);
		memcpy(&mamp->media_info.density_name, "AIT-3  ", 6);
		memcpy(&mamp->AssigningOrganization_1, "SONY", 4);
		put_unaligned_be32(0x17d6, &mamp->media_info.bits_per_mm);
	} else if (!(strncmp(density, "AIT4", 4))) {
		mamp->MediumDensityCode = medium_density_code_ait4;
		mamp->MediaType			= Media_AIT4;
		put_unaligned_be32(384, &mamp->MediumLength);
		put_unaligned_be32(0x50, &mamp->MediumWidth);
		memcpy(&mamp->media_info.description, "AdvIntelligentTape4", 20);
		memcpy(&mamp->media_info.density_name, "AIT-4  ", 6);
		memcpy(&mamp->AssigningOrganization_1, "SONY", 4);
		put_unaligned_be32(0x17d6, &mamp->media_info.bits_per_mm);
	} else if (!(strncmp(density, "DLT3", 4))) {
		mamp->MediumDensityCode = medium_density_code_dlt3;
		mamp->MediaType			= Media_DLT3;
		memcpy(&mamp->media_info.description, "DLTtape III", 11);
		memcpy(&mamp->media_info.density_name, "DLT-III", 7);
		memcpy(&mamp->AssigningOrganization_1, "QUANTUM", 7);
	} else if (!(strncmp(density, "DLT4", 4))) {
		mamp->MediumDensityCode = medium_density_code_dlt4;
		mamp->MediaType			= Media_DLT4;
		memcpy(&mamp->media_info.description, "DLTtape IV", 10);
		memcpy(&mamp->media_info.density_name, "DLT-IV", 6);
		memcpy(&mamp->AssigningOrganization_1, "QUANTUM", 7);
	} else if (!(strncmp(density, "SDLT1", 5))) {
		mamp->MediumDensityCode = 0x48;
		mamp->MediaType			= Media_SDLT;
		memcpy(&mamp->media_info.description, "SDLT I media", 12);
		memcpy(&mamp->media_info.density_name, "SDLT-1", 6);
		memcpy(&mamp->AssigningOrganization_1, "QUANTUM", 7);
		put_unaligned_be32(133000, &mamp->media_info.bits_per_mm);
	} else if (!(strncmp(density, "SDLT220", 7))) {
		mamp->MediumDensityCode = medium_density_code_220;
		mamp->MediaType			= Media_SDLT220;
		memcpy(&mamp->media_info.description, "SDLT I media", 12);
		memcpy(&mamp->media_info.density_name, "SDLT220", 7);
		memcpy(&mamp->AssigningOrganization_1, "QUANTUM", 7);
		put_unaligned_be32(133000, &mamp->media_info.bits_per_mm);
	} else if (!(strncmp(density, "SDLT320", 7))) {
		mamp->MediumDensityCode = medium_density_code_320;
		mamp->MediaType			= Media_SDLT320;
		memcpy(&mamp->media_info.description, "SDLT I media", 12);
		memcpy(&mamp->media_info.density_name, "SDLT320", 7);
		memcpy(&mamp->AssigningOrganization_1, "QUANTUM", 7);
		put_unaligned_be32(190000, &mamp->media_info.bits_per_mm);
	} else if (!(strncmp(density, "SDLT600", 7))) {
		mamp->MediumDensityCode = medium_density_code_600;
		mamp->MediaType			= Media_SDLT600;
		memcpy(&mamp->media_info.description, "SDLT II media", 13);
		memcpy(&mamp->media_info.density_name, "SDLT600", 7);
		memcpy(&mamp->AssigningOrganization_1, "QUANTUM", 7);
		put_unaligned_be32(233000, &mamp->media_info.bits_per_mm);
	} else if (!(strncmp(density, "9840A", 5))) {
		mamp->MediumDensityCode = medium_density_code_9840A;
		mamp->MediaType			= Media_9840A;
		memcpy(&mamp->media_info.description, "Raven 20 GB", 11);
		memcpy(&mamp->media_info.density_name, "R-20", 4);
		memcpy(&mamp->AssigningOrganization_1, "STK", 3);
		put_unaligned_be32(0, &mamp->media_info.bits_per_mm);
		put_unaligned_be16(288, &mamp->media_info.tracks);
		put_unaligned_be32(127, &mamp->MediumWidth);
		put_unaligned_be32(1024, &mamp->MediumLength);
	} else if (!(strncmp(density, "9840B", 5))) {
		mamp->MediumDensityCode = medium_density_code_9840B;
		mamp->MediaType			= Media_9840B;
		memcpy(&mamp->media_info.description, "Raven 20 GB", 11);
		memcpy(&mamp->media_info.density_name, "R-20", 4);
		memcpy(&mamp->AssigningOrganization_1, "STK", 3);
		put_unaligned_be32(0, &mamp->media_info.bits_per_mm);
		put_unaligned_be16(288, &mamp->media_info.tracks);
		put_unaligned_be32(127, &mamp->MediumWidth);
		put_unaligned_be32(1024, &mamp->MediumLength);
	} else if (!(strncmp(density, "9840C", 5))) {
		mamp->MediumDensityCode = medium_density_code_9840C;
		mamp->MediaType			= Media_9840C;
		memcpy(&mamp->media_info.description, "Raven 40 GB", 11);
		memcpy(&mamp->media_info.density_name, "R-40", 4);
		memcpy(&mamp->AssigningOrganization_1, "STK", 3);
		put_unaligned_be32(0, &mamp->media_info.bits_per_mm);
		put_unaligned_be16(288, &mamp->media_info.tracks);
		put_unaligned_be32(127, &mamp->MediumWidth);
		put_unaligned_be32(1024, &mamp->MediumLength);
	} else if (!(strncmp(density, "9840D", 5))) {
		mamp->MediumDensityCode = medium_density_code_9840D;
		mamp->MediaType			= Media_9840D;
		memcpy(&mamp->media_info.description, "Raven 75 GB", 11);
		memcpy(&mamp->media_info.density_name, "R-75", 4);
		memcpy(&mamp->AssigningOrganization_1, "STK", 3);
		put_unaligned_be32(0, &mamp->media_info.bits_per_mm);
		put_unaligned_be16(576, &mamp->media_info.tracks);
		put_unaligned_be32(127, &mamp->MediumWidth);
		put_unaligned_be32(1024, &mamp->MediumLength);
	} else if (!(strncmp(density, "9940A", 5))) {
		mamp->MediumDensityCode = medium_density_code_9940A;
		mamp->MediaType			= Media_9940A;
		memcpy(&mamp->media_info.description, "PeakCapacity 60 GB", 18);
		memcpy(&mamp->media_info.density_name, "P-60", 4);
		memcpy(&mamp->AssigningOrganization_1, "STK", 3);
		put_unaligned_be32(0, &mamp->media_info.bits_per_mm);
		put_unaligned_be16(288, &mamp->media_info.tracks);
		put_unaligned_be32(127, &mamp->MediumWidth);
		put_unaligned_be32(1024, &mamp->MediumLength);
	} else if (!(strncmp(density, "9940B", 5))) {
		mamp->MediumDensityCode = medium_density_code_9940B;
		mamp->MediaType			= Media_9940B;
		memcpy(&mamp->media_info.description,
			   "PeakCapacity 200 GB", 19);
		memcpy(&mamp->media_info.density_name, "P-200", 5);
		memcpy(&mamp->AssigningOrganization_1, "STK", 3);
		put_unaligned_be32(0, &mamp->media_info.bits_per_mm);
		put_unaligned_be16(576, &mamp->media_info.tracks);
		put_unaligned_be32(127, &mamp->MediumWidth);
		put_unaligned_be32(1024, &mamp->MediumLength);
	} else if (!(strncmp(density, "T10KA", 5))) {
		mamp->MediumDensityCode = medium_density_code_10kA;
		mamp->MediaType			= Media_T10KA;
		memcpy(&mamp->media_info.description, "STK T10KA media", 15);
		memcpy(&mamp->media_info.density_name, "T10000A", 7);
		memcpy(&mamp->AssigningOrganization_1, "STK", 3);
		put_unaligned_be32(233000, &mamp->media_info.bits_per_mm);
	} else if (!(strncmp(density, "T10KB", 5))) {
		mamp->MediumDensityCode = medium_density_code_10kB;
		mamp->MediaType			= Media_T10KB;
		memcpy(&mamp->media_info.description, "STK T10KB media", 15);
		memcpy(&mamp->media_info.density_name, "T10000B", 7);
		memcpy(&mamp->AssigningOrganization_1, "STK", 3);
		put_unaligned_be32(233000, &mamp->media_info.bits_per_mm);
	} else if (!(strncmp(density, "T10KC", 5))) {
		mamp->MediumDensityCode = medium_density_code_10kC;
		mamp->MediaType			= Media_T10KC;
		memcpy(&mamp->media_info.description, "STK T10KC media", 15);
		memcpy(&mamp->media_info.density_name, "T10000C", 7);
		memcpy(&mamp->AssigningOrganization_1, "STK", 3);
		put_unaligned_be32(233000, &mamp->media_info.bits_per_mm);
	} else if (!(strncmp(density, "DDS1", 4))) {
		mamp->MediumDensityCode = medium_density_code_DDS1;
		mamp->MediaType			= Media_DDS1;
		memcpy(&mamp->media_info.description, "4MM DDS-1 media", 15);
		memcpy(&mamp->media_info.density_name, "DDS1", 4);
		memcpy(&mamp->AssigningOrganization_1, "HP", 2);
		put_unaligned_be32(233000, &mamp->media_info.bits_per_mm);
	} else if (!(strncmp(density, "DDS2", 4))) {
		mamp->MediumDensityCode = medium_density_code_DDS2;
		mamp->MediaType			= Media_DDS2;
		memcpy(&mamp->media_info.description, "4MM DDS-2 media", 15);
		memcpy(&mamp->media_info.density_name, "DDS2", 4);
		memcpy(&mamp->AssigningOrganization_1, "HP", 2);
		put_unaligned_be32(233000, &mamp->media_info.bits_per_mm);
	} else if (!(strncmp(density, "DDS3", 4))) {
		mamp->MediumDensityCode = medium_density_code_DDS3;
		mamp->MediaType			= Media_DDS3;
		memcpy(&mamp->media_info.description, "4MM DDS-3 media", 15);
		memcpy(&mamp->media_info.density_name, "DDS3", 4);
		memcpy(&mamp->AssigningOrganization_1, "HP", 2);
		put_unaligned_be32(233000, &mamp->media_info.bits_per_mm);
	} else if (!(strncmp(density, "DDS4", 4))) {
		mamp->MediumDensityCode = medium_density_code_DDS4;
		mamp->MediaType			= Media_DDS4;
		memcpy(&mamp->media_info.description, "4MM DDS-4 media", 15);
		memcpy(&mamp->media_info.density_name, "DDS4", 4);
		memcpy(&mamp->AssigningOrganization_1, "HP", 2);
		put_unaligned_be32(233000, &mamp->media_info.bits_per_mm);
	} else if (!(strncmp(density, "J1A", 3))) {
		mamp->MediumDensityCode = medium_density_code_j1a;
		mamp->MediaType			= Media_3592_JA;
		memcpy(&mamp->media_info.description, "3592 J1A media", 14);
		memcpy(&mamp->media_info.density_name, "3592J1A", 7);
		memcpy(&mamp->AssigningOrganization_1, "IBM", 3);
		put_unaligned_be32(233000, &mamp->media_info.bits_per_mm);
	} else if (!(strncmp(density, "E05", 3))) {
		mamp->MediumDensityCode = medium_density_code_e05;
		mamp->MediaType			= Media_3592_JB;
		memcpy(&mamp->media_info.description, "3592 E05 media", 14);
		memcpy(&mamp->media_info.density_name, "3592E05", 7);
		memcpy(&mamp->AssigningOrganization_1, "IBM", 3);
		put_unaligned_be32(233000, &mamp->media_info.bits_per_mm);
	} else if (!(strncmp(density, "E06", 3))) {
		mamp->MediumDensityCode = medium_density_code_e06;
		mamp->MediaType			= Media_3592_JX;
		memcpy(&mamp->media_info.description, "3592 E06 media", 14);
		memcpy(&mamp->media_info.density_name, "3592E06", 7);
		memcpy(&mamp->AssigningOrganization_1, "IBM", 3);
	} else if (!(strncmp(density, "E07", 3))) {
		mamp->MediumDensityCode = medium_density_code_e07;
		mamp->MediaType			= Media_3592_JK;
		memcpy(&mamp->media_info.description, "3592 E07 media", 14);
		memcpy(&mamp->media_info.density_name, "3592E07", 7);
		memcpy(&mamp->AssigningOrganization_1, "IBM", 3);
	} else
		printf("'%s' is an invalid density\n", density);

	if (mamp->MediaType == Media_undefined) {
		printf("Warning: mamp->MediaType is still undefined\n");
		return 1;
	}
	mamp->FormattedDensityCode = mamp->MediumDensityCode;
	return 0;
}

void ymd(int *year, int *month, int *day, int *hh, int *min, int *sec) {
	sscanf(__TIME__, "%d:%d:%d", hh, min, sec);

	if (sscanf(__DATE__, "Jan %d %d", day, year) == 2)
		*month = 1;
	if (sscanf(__DATE__, "Feb %d %d", day, year) == 2)
		*month = 2;
	if (sscanf(__DATE__, "Mar %d %d", day, year) == 2)
		*month = 3;
	if (sscanf(__DATE__, "Apr %d %d", day, year) == 2)
		*month = 4;
	if (sscanf(__DATE__, "May %d %d", day, year) == 2)
		*month = 5;
	if (sscanf(__DATE__, "Jun %d %d", day, year) == 2)
		*month = 6;
	if (sscanf(__DATE__, "Jul %d %d", day, year) == 2)
		*month = 7;
	if (sscanf(__DATE__, "Aug %d %d", day, year) == 2)
		*month = 8;
	if (sscanf(__DATE__, "Sep %d %d", day, year) == 2)
		*month = 9;
	if (sscanf(__DATE__, "Oct %d %d", day, year) == 2)
		*month = 10;
	if (sscanf(__DATE__, "Nov %d %d", day, year) == 2)
		*month = 11;
	if (sscanf(__DATE__, "Dec %d %d", day, year) == 2)
		*month = 12;
}

void opcode_6_params(struct scsi_cmd *cmd, int *num, int *sz) {
	uint8_t *cdb = cmd->scb;

	if (cdb[1] & FIXED_BLOCK) { /* If Fixed block writes */
		*num = get_unaligned_be24(&cdb[2]);
		*sz	 = get_unaligned_be24(&modeBlockDescriptor[5]);
	} else { /* else - Variable Block writes */
		*num = 1;
		*sz	 = get_unaligned_be24(&cdb[2]);
	}
}

char *slot_type_str(int type) {
	return slot_type_string[type];
}

void init_smc_log_pages(struct lu_phy_attr *lu) {
	add_log_temperature_page(lu);
	add_log_tape_alert(lu);
}

void init_smc_mode_pages(struct lu_phy_attr *lu) {
	add_mode_disconnect_reconnect(lu);
	add_mode_control_extension(lu);
	add_mode_power_condition(lu);
	add_mode_information_exception(lu);
	add_mode_element_address_assignment(lu);
	add_mode_transport_geometry(lu);
	add_mode_device_capabilities(lu);
}

void bubbleSort(int *array, int size) {
	int swapped;
	int i;
	int j;

	for (i = 1; i < size; i++) {
		swapped = 0;
		for (j = 0; j < size - i; j++) {
			if (array[j] > array[j + 1]) {
				int temp	 = array[j];
				array[j]	 = array[j + 1];
				array[j + 1] = temp;
				swapped		 = 1;
			}
		}
		if (!swapped)
			break; /* if it is sorted then stop */
	}
}

void sort_library_slot_type(struct lu_phy_attr *lu, struct smc_type_slot *type) {
	int				 i;
	struct smc_priv *smc_p = lu->lu_private;
	int				 arr[4];

	arr[0] = smc_p->pm->start_drive;
	arr[1] = smc_p->pm->start_picker;
	arr[2] = smc_p->pm->start_map;
	arr[3] = smc_p->pm->start_storage;

	bubbleSort(arr, 4);

	for (i = 0; i < 4; i++) {
		if (smc_p->pm->start_drive == arr[i]) {
			type[i].type  = DATA_TRANSFER;
			type[i].start = smc_p->pm->start_drive;
		}
		if (smc_p->pm->start_picker == arr[i]) {
			type[i].type  = MEDIUM_TRANSPORT;
			type[i].start = smc_p->pm->start_picker;
		}
		if (smc_p->pm->start_map == arr[i]) {
			type[i].type  = MAP_ELEMENT;
			type[i].start = smc_p->pm->start_map;
		}
		if (smc_p->pm->start_storage == arr[i]) {
			type[i].type  = STORAGE_ELEMENT;
			type[i].start = smc_p->pm->start_storage;
		}
	}
}

/* Set VPD data with device serial number */
void update_vpd_80(struct lu_phy_attr *lu, void *p) {
	struct vpd *vpd_pg = lu->lu_vpd[PCODE_OFFSET(0x80)];

	assert(vpd_pg); /* space should have been pre-allocated */

	memcpy(vpd_pg->data, p, strlen((const char *)p));
}

void update_vpd_83(struct lu_phy_attr *lu, void *p) {
	struct vpd *vpd_pg = lu->lu_vpd[PCODE_OFFSET(0x83)];
	uint8_t	   *d;
	char	   *ptr;
	int			num;
	int			len, j;

	assert(vpd_pg); /* space should have been pre-allocated */

	d = vpd_pg->data;

	d[0] = 2;
	d[1] = 1;
	d[2] = 0;
	num	 = VENDOR_ID_LEN + PRODUCT_ID_LEN + 10;
	d[3] = num;

	memcpy(&d[4], &lu->vendor_id, VENDOR_ID_LEN);
	memcpy(&d[12], &lu->product_id, PRODUCT_ID_LEN);
	memcpy(&d[28], &lu->lu_serial_no, 10);
	len = (int)strlen(lu->lu_serial_no);
	ptr = &lu->lu_serial_no[len];

	num += 4;
	/* NAA IEEE registered identifier (faked) */
	d[num]		= 0x1; /* Binary */
	d[num + 1]	= 0x3;
	d[num + 2]	= 0x0;
	d[num + 3]	= 0x8;
	d[num + 4]	= 0x51;
	d[num + 5]	= 0x23;
	d[num + 6]	= 0x45;
	d[num + 7]	= 0x60;
	d[num + 8]	= 0x3;
	d[num + 9]	= 0x3;
	d[num + 10] = 0x3;
	d[num + 11] = 0x3;

	if (lu->naa) { /* If defined in config file */
		sscanf((const char *)lu->naa,
			   "%hhx:%hhx:%hhx:%hhx:%hhx:%hhx:%hhx:%hhx",
			   &d[num + 4],
			   &d[num + 5],
			   &d[num + 6],
			   &d[num + 7],
			   &d[num + 8],
			   &d[num + 9],
			   &d[num + 10],
			   &d[num + 11]);
	} else { /* Else munge the serial number */
		ptr--;
		for (j = 11; j > 3; ptr--, j--)
			d[num + j] = *ptr;
	}
	/* Bug reported by Stefan Hauser.
	 * [num +4] is always 0x5x
	 */
	d[num + 4] &= 0x0f;
	d[num + 4] |= 0x50;
}
